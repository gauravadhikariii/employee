-- PeopleOS database schema for Supabase (PostgreSQL)
-- Run this in Supabase Dashboard -> SQL Editor after creating a free project.
-- IMPORTANT: RLS is enabled on every table. Never expose the service-role key in the browser.

create extension if not exists pgcrypto;

do $$ begin
  create type public.peopleos_role as enum ('admin', 'employee');
exception when duplicate_object then null;
end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null unique,
  role public.peopleos_role not null default 'employee',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Admin identity/profile data is kept apart from employee records.
create table if not exists public.admin_profiles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  full_name text not null,
  title text not null default 'Administrator',
  department text not null default 'People & Culture',
  location text not null default '',
  phone text not null default '',
  timezone text not null default 'Asia/Kolkata',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.employees (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  employee_code text unique,
  full_name text not null,
  email text not null unique,
  title text not null default '',
  department text not null default '',
  location text not null default '',
  phone text not null default '',
  timezone text not null default 'Asia/Kolkata',
  start_date date not null default current_date,
  status text not null default 'Active' check (status in ('Active', 'On leave', 'Inactive')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Sensitive salary/compensation data is isolated and visible to admins only.
create table if not exists public.employee_compensation (
  employee_id uuid primary key references public.employees(user_id) on delete cascade,
  annual_salary numeric(14,2) not null default 0 check (annual_salary >= 0),
  currency text not null default 'INR',
  updated_at timestamptz not null default now()
);

create table if not exists public.attendance (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references public.employees(user_id) on delete cascade,
  attendance_date date not null,
  status text not null default 'Present' check (status in ('Present', 'Late', 'Remote', 'Absent', 'On leave')),
  check_in time,
  check_out time,
  location text not null default 'Office',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (employee_id, attendance_date)
);

create table if not exists public.leave_requests (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid not null references public.employees(user_id) on delete cascade,
  leave_type text not null,
  start_date date not null,
  end_date date not null,
  days integer not null check (days > 0),
  reason text not null default '',
  status text not null default 'Pending' check (status in ('Pending', 'Approved', 'Rejected')),
  submitted_at timestamptz not null default now(),
  reviewed_at timestamptz,
  reviewed_by uuid references public.profiles(id) on delete set null,
  check (end_date >= start_date)
);

create index if not exists attendance_employee_date_idx on public.attendance(employee_id, attendance_date desc);
create index if not exists leave_requests_employee_idx on public.leave_requests(employee_id, submitted_at desc);
create index if not exists leave_requests_status_idx on public.leave_requests(status, submitted_at desc);

-- Auth users become employees by default. Admin role is assigned explicitly by the project owner.
create or replace function public.peopleos_handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, role)
  values (new.id, lower(new.email), 'employee')
  on conflict (id) do update set email = excluded.email;
  return new;
end;
$$;

drop trigger if exists peopleos_auth_user_created on auth.users;
create trigger peopleos_auth_user_created
after insert on auth.users
for each row execute procedure public.peopleos_handle_new_auth_user();

-- RLS helper. SECURITY DEFINER avoids recursive RLS evaluation on profiles.
create or replace function public.peopleos_is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin'
  );
$$;

alter table public.profiles enable row level security;
alter table public.admin_profiles enable row level security;
alter table public.employees enable row level security;
alter table public.employee_compensation enable row level security;
alter table public.attendance enable row level security;
alter table public.leave_requests enable row level security;

-- Clear policies by name so this migration can be run again safely.
drop policy if exists profiles_read_self_or_admin on public.profiles;
drop policy if exists admin_profiles_admin_all on public.admin_profiles;
drop policy if exists employees_admin_all on public.employees;
drop policy if exists employees_self_read on public.employees;
drop policy if exists compensation_admin_all on public.employee_compensation;
drop policy if exists attendance_admin_all on public.attendance;
drop policy if exists attendance_employee_read_own on public.attendance;
drop policy if exists leaves_admin_all on public.leave_requests;
drop policy if exists leaves_employee_read_own on public.leave_requests;
drop policy if exists leaves_employee_create_own on public.leave_requests;

create policy profiles_read_self_or_admin on public.profiles
  for select to authenticated
  using (id = auth.uid() or public.peopleos_is_admin());

create policy admin_profiles_admin_all on public.admin_profiles
  for all to authenticated
  using (public.peopleos_is_admin())
  with check (public.peopleos_is_admin());

create policy employees_admin_all on public.employees
  for all to authenticated
  using (public.peopleos_is_admin())
  with check (public.peopleos_is_admin());
create policy employees_self_read on public.employees
  for select to authenticated
  using (user_id = auth.uid());

create policy compensation_admin_all on public.employee_compensation
  for all to authenticated
  using (public.peopleos_is_admin())
  with check (public.peopleos_is_admin());

create policy attendance_admin_all on public.attendance
  for all to authenticated
  using (public.peopleos_is_admin())
  with check (public.peopleos_is_admin());
create policy attendance_employee_read_own on public.attendance
  for select to authenticated
  using (employee_id = auth.uid());

create policy leaves_admin_all on public.leave_requests
  for all to authenticated
  using (public.peopleos_is_admin())
  with check (public.peopleos_is_admin());
create policy leaves_employee_read_own on public.leave_requests
  for select to authenticated
  using (employee_id = auth.uid());
create policy leaves_employee_create_own on public.leave_requests
  for insert to authenticated
  with check (
    employee_id = auth.uid()
    and status = 'Pending'
    and reviewed_by is null
  );

-- Authenticated employees can read their own rows; the admin role can manage all rows.
-- Employee self-service changes use narrowly scoped SECURITY DEFINER functions below.
grant select on public.profiles, public.admin_profiles, public.employees, public.employee_compensation, public.attendance, public.leave_requests to authenticated;
grant insert, update, delete on public.admin_profiles, public.employees, public.employee_compensation, public.attendance, public.leave_requests to authenticated;
revoke insert, update, delete on public.profiles from anon, authenticated;

create or replace function public.peopleos_update_my_employee_profile(
  p_full_name text,
  p_phone text,
  p_location text,
  p_timezone text default 'Asia/Kolkata'
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not exists (select 1 from public.profiles where id = auth.uid() and role = 'employee') then
    raise exception 'Employee account required';
  end if;
  update public.employees
  set full_name = p_full_name,
      phone = coalesce(p_phone, ''),
      location = coalesce(p_location, ''),
      timezone = coalesce(p_timezone, 'Asia/Kolkata'),
      updated_at = now()
  where user_id = auth.uid();
  if not found then raise exception 'Employee profile not found'; end if;
end;
$$;

grant execute on function public.peopleos_update_my_employee_profile(text, text, text, text) to authenticated;

create or replace function public.peopleos_update_my_admin_profile(
  p_full_name text,
  p_title text,
  p_department text,
  p_phone text,
  p_location text,
  p_timezone text default 'Asia/Kolkata'
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.peopleos_is_admin() then raise exception 'Admin account required'; end if;
  update public.admin_profiles
  set full_name = p_full_name,
      title = p_title,
      department = p_department,
      phone = coalesce(p_phone, ''),
      location = coalesce(p_location, ''),
      timezone = coalesce(p_timezone, 'Asia/Kolkata'),
      updated_at = now()
  where user_id = auth.uid();
  if not found then raise exception 'Admin profile not found'; end if;
end;
$$;

grant execute on function public.peopleos_update_my_admin_profile(text, text, text, text, text, text) to authenticated;

-- Employee clock actions cannot set another employee's ID or spoof their own attendance status.
create or replace function public.peopleos_clock_in(p_location text default 'Office')
returns public.attendance
language plpgsql
security definer
set search_path = public
as $$
declare
  v_row public.attendance;
  v_today date := (timezone('Asia/Kolkata', now()))::date;
  v_time time := (timezone('Asia/Kolkata', now()))::time;
begin
  if not exists (select 1 from public.profiles where id = auth.uid() and role = 'employee') then
    raise exception 'Employee account required';
  end if;
  insert into public.attendance as existing(employee_id, attendance_date, status, check_in, location)
  values (auth.uid(), v_today, 'Present', v_time, coalesce(nullif(p_location, ''), 'Office'))
  on conflict (employee_id, attendance_date) do update
    set check_in = coalesce(existing.check_in, excluded.check_in),
        status = 'Present',
        location = excluded.location,
        updated_at = now()
  returning * into v_row;
  return v_row;
end;
$$;

grant execute on function public.peopleos_clock_in(text) to authenticated;

create or replace function public.peopleos_clock_out()
returns public.attendance
language plpgsql
security definer
set search_path = public
as $$
declare
  v_row public.attendance;
  v_today date := (timezone('Asia/Kolkata', now()))::date;
begin
  if not exists (select 1 from public.profiles where id = auth.uid() and role = 'employee') then
    raise exception 'Employee account required';
  end if;
  update public.attendance
  set check_out = (timezone('Asia/Kolkata', now()))::time,
      updated_at = now()
  where employee_id = auth.uid()
    and attendance_date = v_today
    and check_in is not null
    and check_out is null
  returning * into v_row;
  if not found then raise exception 'No open clock-in found for today'; end if;
  return v_row;
end;
$$;

grant execute on function public.peopleos_clock_out() to authenticated;

-- After running this schema, create your first Auth user in Supabase Dashboard.
-- Then use the setup guide to assign that account the admin role and insert admin_profiles.
