import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const anonKey = Deno.env.get('SUPABASE_ANON_KEY') ?? Deno.env.get('SUPABASE_PUBLISHABLE_KEY')!;
const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info',
  'Access-Control-Allow-Methods': 'POST, DELETE, OPTIONS',
  'Content-Type': 'application/json'
};

function json(status: number, body: Record<string, unknown>) {
  return new Response(JSON.stringify(body), { status, headers: corsHeaders });
}

Deno.serve(async (request: Request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (!['POST', 'DELETE'].includes(request.method)) return json(405, { error: 'Method not allowed' });

  const authorization = request.headers.get('Authorization');
  if (!authorization?.startsWith('Bearer ')) return json(401, { error: 'Sign in required' });

  // Validate the caller's user token first; never trust a role sent by the browser.
  const callerClient = createClient(supabaseUrl, anonKey, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: { Authorization: authorization } }
  });
  const { data: callerResult, error: callerError } = await callerClient.auth.getUser();
  const caller = callerResult?.user;
  if (callerError || !caller) return json(401, { error: 'Invalid or expired session' });

  const service = createClient(supabaseUrl, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false }
  });
  const { data: callerProfile, error: profileError } = await service
    .from('profiles')
    .select('role')
    .eq('id', caller.id)
    .maybeSingle();
  if (profileError || callerProfile?.role !== 'admin') return json(403, { error: 'Administrator access required' });

  if (request.method === 'DELETE') {
    let payload: { user_id?: string };
    try { payload = await request.json(); } catch { return json(400, { error: 'Invalid JSON body' }); }
    if (!payload.user_id) return json(400, { error: 'user_id is required' });
    const { data: target, error: targetError } = await service
      .from('profiles')
      .select('id, role')
      .eq('id', payload.user_id)
      .maybeSingle();
    if (targetError || !target || target.role !== 'employee') return json(404, { error: 'Employee account not found' });
    const { error: deleteError } = await service.auth.admin.deleteUser(payload.user_id);
    if (deleteError) return json(400, { error: deleteError.message });
    return json(200, { ok: true });
  }

  let payload: {
    email?: string;
    password?: string;
    full_name?: string;
    employee_code?: string;
    title?: string;
    department?: string;
    location?: string;
    phone?: string;
    start_date?: string;
    status?: string;
    annual_salary?: number;
  };
  try { payload = await request.json(); } catch { return json(400, { error: 'Invalid JSON body' }); }

  const email = String(payload.email ?? '').trim().toLowerCase();
  const password = String(payload.password ?? '');
  const fullName = String(payload.full_name ?? '').trim();
  if (!email || !email.includes('@') || !fullName) return json(400, { error: 'Valid email and full_name are required' });
  if (password.length < 8) return json(400, { error: 'Temporary password must be at least 8 characters' });
  if (payload.status && !['Active', 'On leave', 'Inactive'].includes(payload.status)) return json(400, { error: 'Invalid employee status' });

  const { data: created, error: createError } = await service.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    user_metadata: { full_name: fullName }
  });
  const employeeUser = created?.user;
  if (createError || !employeeUser) return json(400, { error: createError?.message ?? 'Could not create employee account' });

  const { error: employeeError } = await service.from('employees').insert({
    user_id: employeeUser.id,
    employee_code: payload.employee_code || null,
    full_name: fullName,
    email,
    title: payload.title || '',
    department: payload.department || '',
    location: payload.location || '',
    phone: payload.phone || '',
    start_date: payload.start_date || new Date().toISOString().slice(0, 10),
    status: payload.status || 'Active'
  });
  if (employeeError) {
    await service.auth.admin.deleteUser(employeeUser.id);
    return json(400, { error: employeeError.message });
  }

  if (Number.isFinite(Number(payload.annual_salary)) && Number(payload.annual_salary) > 0) {
    const { error: salaryError } = await service.from('employee_compensation').insert({
      employee_id: employeeUser.id,
      annual_salary: Number(payload.annual_salary),
      currency: 'INR'
    });
    if (salaryError) {
      await service.auth.admin.deleteUser(employeeUser.id);
      return json(400, { error: salaryError.message });
    }
  }

  return json(201, { ok: true, user_id: employeeUser.id, email });
});
